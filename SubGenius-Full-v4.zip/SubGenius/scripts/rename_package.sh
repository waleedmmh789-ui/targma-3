#!/usr/bin/env bash
# يغيّر اسم الحزمة بالكامل. مثال: bash scripts/rename_package.sh com.mycompany.subgenius
set -euo pipefail
NEW="${1:?usage: rename_package.sh <new.package.name>}"
OLD="com.subgenius.app"
cd "$(dirname "$0")/.."
OLD_PATH="app/src/main/java/$(echo $OLD | tr . /)"
NEW_PATH="app/src/main/java/$(echo $NEW | tr . /)"
mkdir -p "$(dirname "$NEW_PATH")"
mv "$OLD_PATH" "$NEW_PATH"
# حذف مجلدات الحزمة القديمة الفارغة
find app/src/main/java -type d -empty -delete 2>/dev/null || true
grep -rl "$OLD" app --include=*.kt --include=*.kts --include=*.xml | xargs sed -i "s/$OLD/$NEW/g"
echo "تم. الحزمة الآن: $NEW"
