package com.subgenius.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.subgenius.app.AppLinks
import com.subgenius.app.ui.components.TopBar
import com.subgenius.app.ui.theme.BgDark
import com.subgenius.app.ui.theme.TextGray
import com.subgenius.app.ui.theme.TextWhite
import com.subgenius.app.ui.theme.WarnYellow

private data class AboutSection(val title: String, val lines: List<String>)

private val aboutSections = listOf(
    AboutSection("ما هو التطبيق وماذا يفعل؟", listOf(
        "أداة تعمل على هاتفك لترجمة الفيديوهات ودبلجتها. كل المعالجة محلية، ولا تُرفع فيديوهاتك أو صوتك لأي خادم.",
        "يستخرج الكلام من الفيديو إلى نص بمحرّكين: Whisper (الأدق، وأفضل مع اللهجات) وVosk (الأسرع).",
        "يترجم النص إما دون إنترنت (Google ML Kit)، أو أونلاين مجاناً (Lingva وMyMemory) فيُرسَل النص فقط.",
        "يدبلج الفيديو بصوت محرك «تحويل النص إلى كلام» في هاتفك، ويضع كل جملة في توقيت الكلام الأصلي، مع تقريب طبقة صوت المتكلم (رجل أو سيدة أو طفل). هذا تقريب للطبقة وليس استنساخاً لصوته.",
        "يحرق الترجمة على الفيديو، ويضغطه، ويحفظه في المعرض داخل Movies/SubGenius."
    )),
    AboutSection("الأجزاء السريعة وسبب سرعتها", listOf(
        "Vosk: نماذجه صغيرة (نحو 40MB) وخفيفة على المعالج والذاكرة، فيعمل غالباً أسرع من زمن الفيديو على الهواتف المتوسطة.",
        "الترجمة دون إنترنت (ML Kit): نماذج صغيرة ومضغوطة، فتُترجم الجملة في أجزاء من الثانية بعد التنزيل الأول.",
        "دمج الدبلجة مع الفيديو: تُنسخ الصورة كما هي دون إعادة ترميز، فتنتهي الخطوة في ثوانٍ.",
        "الضغط وحرق الترجمة: سريعان حين يوفّر الهاتف مرمّز الفيديو العتادي (MediaCodec).",
        "نماذج Whisper المضغوطة (q5): أصغر حجماً وأسرع من الأصلية بدقة قريبة."
    )),
    AboutSection("الأجزاء البطيئة وسبب بطئها", listOf(
        "Whisper: شبكة عصبية كبيرة (مئات الملايين من المعاملات) تُنفَّذ على المعالج، وتعالج الصوت مقاطع من 30 ثانية. قد يستغرق وقتاً يفوق زمن الفيديو على الهواتف الضعيفة.",
        "نموذج Vosk العربي (MGB2 نحو 320MB): كبير، يحتاج ذاكرة ووقتاً للتحميل في الذاكرة.",
        "الدبلجة: يُولَّد صوت لكل جملة ثم يُحوَّل ويُوضع في موضعه، فتطول كلما طال الفيديو وكثرت الجمل.",
        "حرق الترجمة بالمرمّز البرمجي (libx264) حين لا يتوفر مرمّز العتاد: يعيد ترميز الفيديو كله فيكون أبطأ.",
        "تنزيل النماذج في أول مرة والترجمة الأونلاين: يعتمدان على سرعة الإنترنت.",
        "الحرارة: الأعمال الطويلة ترفع حرارة الهاتف، فيخفّض النظام سرعة المعالج تلقائياً."
    )),
    AboutSection("المعالجات التي تتحمل العمل (تقديرات عامة وليست قياسات مخبرية)", listOf(
        "Whisper وVosk يعملان على المعالج المركزي (CPU) وليس على وحدة الذكاء الاصطناعي NPU أو كرت الشاشة، فقوة أنوية المعالج وحجم الذاكرة هما المحدِّد.",
        "ممتاز (Whisper Small المضغوط بسلاسة نسبية): Snapdragon 8 Gen 1 وما بعده، وSnapdragon 888 و865 و870، وDimensity 9000 وما بعده، وExynos 2200 وما بعده، وGoogle Tensor G2 وما بعده، مع ذاكرة 8GB فأكثر.",
        "جيد (Vosk سريع، وWhisper ببطء مقبول): Snapdragon 7 Gen 1 وما بعده، و778G و750G، وDimensity 7000 و8000 و1100 و1200، وExynos 1380 و2100، مع 6GB فأكثر.",
        "متوسط أو ضعيف (يُنصح بـ Vosk وWhisper Base المضغوط على مسؤوليتك): Snapdragon 6xx و4xx مثل 680 و695، وHelio G85 وG88 وG96، وDimensity 700 و810، وUnisoc، مع 3 إلى 4GB.",
        "غير مدعوم: الهواتف ذات المعمارية 32 بت فقط. التطبيق يتطلب arm64 وأندرويد 8 فأحدث.",
        "نصيحة: على الهواتف الضعيفة استعمل Vosk مع الفيديوهات القصيرة، وأغلق التطبيقات الأخرى، ووصّل الشاحن."
    ))
)

private val disclaimerItems = listOf(
        "التطبيق أداة تقنية مساعدة يقدّمها المطوّر كما هي، دون أي ضمان، بما في ذلك دقة الاستخراج أو الترجمة أو الدبلجة أو ملاءمتها لغرض معين.",
        "المستخدم وحده هو المسؤول عن كل استعمال للتطبيق وعن نتائجه، ويتحمل وحده أي مسؤولية قانونية أو مالية أو أدبية أو أخلاقية تنتج عن سوء الاستخدام.",
        "حقوق المحتوى: لا تعالج فيديو إلا إذا كنت تملكه أو لديك إذن صريح بترجمته ودبلجته ونشره. انتهاك حقوق النشر والملكية الفكرية مسؤوليتك وحدك.",
        "الأصوات: يُمنع استعمال الدبلجة لانتحال شخصية أي إنسان أو تقليد صوته بقصد الخداع أو التزييف أو الاحتيال أو التشهير أو الإساءة أو التحريض أو نشر الكراهية أو أي محتوى مخالف للقانون أو للأخلاق.",
        "صوت الدبلجة اصطناعي. أفصح عن ذلك لجمهورك حيثما تقتضي القوانين أو سياسات المنصات التي تنشر عليها.",
        "لا تعتمد على النص أو الترجمة دون مراجعة بشرية في الأمور الطبية أو القانونية أو الرسمية أو المالية أو المتعلقة بالسلامة.",
        "المطوّر غير مسؤول عن أي ضرر مباشر أو غير مباشر، مثل فقدان بيانات أو ضرر بالجهاز أو خسارة مالية أو مساس بالسمعة. وهو غير مسؤول عن المحتوى الذي يعالجه المستخدمون ولا عن خدمات الأطراف الثالثة (Google ML Kit وLingva وMyMemory وHugging Face ومحرك تحويل النص إلى كلام في الهاتف).",
        "أنت ملتزم بقوانين بلدك وبشروط المنصات التي تنشر عليها.",
        "يُدين المطوّر ويتبرأ أدبياً وأخلاقياً من أي استعمال مسيء أو غير قانوني للتطبيق، ويحتفظ بحقه في تعديل التطبيق أو إيقافه أو إزالته.",
        "باستعمالك التطبيق فإنك تقرّ بأنك قرأت هذه البنود وتوافق عليها."
)

@Composable
fun AboutScreen(onBack: () -> Unit, onOpenPrivacy: () -> Unit) {
    val uriHandler = LocalUriHandler.current
    Column(Modifier.fillMaxSize().background(BgDark).padding(horizontal = 20.dp).verticalScroll(rememberScrollState())) {
        TopBar("حول التطبيق", onBack)
        aboutSections.forEach { sec ->
            Spacer(Modifier.height(18.dp))
            Text(sec.title, color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            sec.lines.forEach { line ->
                Spacer(Modifier.height(6.dp))
                Text("• " + line, color = TextGray, fontSize = 14.sp)
            }
        }

        Spacer(Modifier.height(24.dp))
        Text("إخلاء المسؤولية القانونية والأدبية والأخلاقية", color = WarnYellow, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        disclaimerItems.forEachIndexed { i, item ->
            Spacer(Modifier.height(8.dp))
            Text("${i + 1}. " + item, color = TextGray, fontSize = 14.sp)
        }

        Spacer(Modifier.height(24.dp))
        Button(
            onClick = { uriHandler.openUri(AppLinks.PRIVACY_URL) },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(14.dp)
        ) { Text("سياسة الخصوصية الكاملة (على الإنترنت)") }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            onClick = onOpenPrivacy,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(14.dp)
        ) { Text("ملخص الخصوصية داخل التطبيق", color = TextWhite) }
        Spacer(Modifier.height(32.dp))
    }
}
