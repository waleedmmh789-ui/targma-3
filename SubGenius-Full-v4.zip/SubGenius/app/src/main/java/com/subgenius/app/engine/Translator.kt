package com.subgenius.app.engine

import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.tasks.await

object TranslatorHelper {
    suspend fun translateSegments(
        sourceLang: String, targetLang: String,
        segments: List<SpeechSegment>, onProgress: (Int) -> Unit = {}
    ): Result<List<SpeechSegment>> {
        var translator: Translator? = null
        return try {
            val src = TranslateLanguage.fromLanguageTag(sourceLang) ?: throw Exception("لغة المصدر غير مدعومة")
            val tgt = TranslateLanguage.fromLanguageTag(targetLang) ?: throw Exception("لغة الهدف غير مدعومة")
            translator = Translation.getClient(
                TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(tgt).build()
            )
            translator.downloadModelIfNeeded().await()
            val out = mutableListOf<SpeechSegment>()
            segments.forEachIndexed { i, seg ->
                out.add(SpeechSegment(translator.translate(seg.text).await(), seg.startMs, seg.endMs))
                onProgress(((i + 1) * 100) / segments.size)
            }
            Result.success(out)
        } catch (e: Exception) {
            Result.failure(e)
        } finally {
            try { translator?.close() } catch (_: Exception) {}
        }
    }
}
