package com.subgenius.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.subgenius.app.ui.AppViewModel
import com.subgenius.app.ui.screens.CustomizeScreen
import com.subgenius.app.ui.screens.AboutScreen
import com.subgenius.app.ui.screens.DownloadScreen
import com.subgenius.app.ui.screens.DubbingScreen
import com.subgenius.app.ui.screens.PrivacyScreen
import com.subgenius.app.ui.screens.ExtractScreen
import com.subgenius.app.ui.screens.HomeScreen
import com.subgenius.app.ui.screens.ProjectsScreen
import com.subgenius.app.ui.screens.TranslateScreen
import com.subgenius.app.ui.screens.VideoScreen

object Routes {
    const val HOME = "home"
    const val VIDEO = "video"
    const val EXTRACT = "extract"
    const val TRANSLATE = "translate"
    const val CUSTOMIZE = "customize"
    const val PROJECTS = "projects"
    const val DOWNLOAD = "download"
    const val DUBBING = "dubbing"
    const val PRIVACY = "privacy"
    const val ABOUT = "about"
}

@Composable
fun NavGraph(navController: NavHostController, appViewModel: AppViewModel, modifier: Modifier = Modifier) {
    NavHost(navController, startDestination = Routes.HOME, modifier = modifier) {
        composable(Routes.HOME) {
            HomeScreen(
                onPickVideo = { uri -> appViewModel.setVideo(uri); navController.navigate(Routes.VIDEO) },
                onOpenProjects = { navController.navigate(Routes.PROJECTS) },
                onOpenDownload = { navController.navigate(Routes.DOWNLOAD) },
                onOpenPrivacy = { navController.navigate(Routes.PRIVACY) },
                onOpenAbout = { navController.navigate(Routes.ABOUT) }
            )
        }
        composable(Routes.VIDEO) {
            VideoScreen(
                appViewModel = appViewModel,
                onBack = { navController.popBackStack() },
                onExtract = { navController.navigate(Routes.EXTRACT) },
                onTranslate = { navController.navigate(Routes.TRANSLATE) },
                onDub = { navController.navigate(Routes.DUBBING) },
                onCustomize = { navController.navigate(Routes.CUSTOMIZE) }
            )
        }
        composable(Routes.EXTRACT) {
            ExtractScreen(
                appViewModel = appViewModel,
                onBack = { navController.popBackStack() },
                onDone = { navController.navigate(Routes.TRANSLATE) }
            )
        }
        composable(Routes.TRANSLATE) {
            TranslateScreen(
                appViewModel = appViewModel,
                onBack = { navController.popBackStack() },
                onDone = { navController.navigate(Routes.CUSTOMIZE) }
            )
        }
        composable(Routes.CUSTOMIZE) {
            CustomizeScreen(appViewModel = appViewModel, onBack = { navController.popBackStack() })
        }
        composable(Routes.DUBBING) {
            DubbingScreen(
                appViewModel = appViewModel,
                onBack = { navController.popBackStack() },
                onTranslate = { navController.navigate(Routes.TRANSLATE) }
            )
        }
        composable(Routes.ABOUT) {
            AboutScreen(
                onBack = { navController.popBackStack() },
                onOpenPrivacy = { navController.navigate(Routes.PRIVACY) }
            )
        }
        composable(Routes.PRIVACY) { PrivacyScreen(onBack = { navController.popBackStack() }) }
        composable(Routes.PROJECTS) { ProjectsScreen(onBack = { navController.popBackStack() }) }
        composable(Routes.DOWNLOAD) { DownloadScreen(onBack = { navController.popBackStack() }) }
    }
}
