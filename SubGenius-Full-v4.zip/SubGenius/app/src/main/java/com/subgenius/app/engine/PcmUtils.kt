package com.subgenius.app.engine

import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs

/** أدوات لصوت PCM خام s16le 16kHz mono */
object PcmUtils {
    const val BYTES_PER_SEC = 32000

    /** يقسم الصوت إلى مقاطع ~chunkSec ثانية، ويقطع عند أهدأ لحظة (±3 ثوانٍ) */
    fun splitRanges(file: File, total: Long, chunkSec: Int): List<Pair<Long, Long>> {
        val n = ((total / BYTES_PER_SEC + chunkSec - 1) / chunkSec).toInt().coerceAtLeast(1)
        if (n == 1) return listOf(0L to total)
        val cuts = mutableListOf(0L)
        for (i in 1 until n) cuts += quietPoint(file, total * i / n, total)
        cuts += total
        return cuts.zipWithNext()
    }

    private fun quietPoint(file: File, target: Long, total: Long): Long {
        val frame = 1600
        val window = 3L * BYTES_PER_SEC
        val from = ((target - window).coerceAtLeast(0)) / 2 * 2
        val to = (target + window).coerceAtMost(total)
        val len = (to - from).toInt()
        if (len < frame * 2) return target / 2 * 2
        val data = ByteArray(len)
        RandomAccessFile(file, "r").use { it.seek(from); it.readFully(data) }
        var best = Long.MAX_VALUE
        var bestPos = target
        var pos = 0
        while (pos + frame <= len) {
            var sum = 0L
            var i = pos
            while (i < pos + frame) {
                val s = (data[i].toInt() and 0xFF) or (data[i + 1].toInt() shl 8)
                sum += abs(s)
                i += 2
            }
            if (sum < best) { best = sum; bestPos = from + pos + frame / 2 }
            pos += frame
        }
        return bestPos / 2 * 2
    }

    /** مقطع صامت تقريباً؟ (يتجنب هلوسة Whisper على الصمت) */
    fun isSilent(file: File, start: Long, end: Long, threshold: Long = 60): Boolean {
        RandomAccessFile(file, "r").use { raf ->
            raf.seek(start)
            val buf = ByteArray(65536)
            var rem = end - start
            var sum = 0L
            var count = 0L
            while (rem > 0) {
                val n = raf.read(buf, 0, minOf(buf.size.toLong(), rem).toInt())
                if (n <= 0) break
                var i = 0
                while (i + 1 < n) {
                    val s = (buf[i].toInt() and 0xFF) or (buf[i + 1].toInt() shl 8)
                    sum += abs(s); count++; i += 2
                }
                rem -= n
            }
            return count == 0L || sum / count < threshold
        }
    }

    /** يكتب جزءاً من PCM كملف WAV (16kHz, mono, 16-bit) */
    fun writeWav(pcm: File, start: Long, end: Long, out: File) {
        val len = (end - start).toInt()
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray()); putInt(36 + len); put("WAVE".toByteArray())
            put("fmt ".toByteArray()); putInt(16)
            putShort(1.toShort()); putShort(1.toShort())
            putInt(16000); putInt(32000)
            putShort(2.toShort()); putShort(16.toShort())
            put("data".toByteArray()); putInt(len)
        }
        out.outputStream().use { os ->
            os.write(header.array())
            RandomAccessFile(pcm, "r").use { raf ->
                raf.seek(start)
                val buf = ByteArray(65536)
                var rem = len.toLong()
                while (rem > 0) {
                    val n = raf.read(buf, 0, minOf(buf.size.toLong(), rem).toInt())
                    if (n <= 0) break
                    os.write(buf, 0, n); rem -= n
                }
            }
        }
    }
}
