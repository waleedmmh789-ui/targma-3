package com.subgenius.app

import android.graphics.Color as AColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.navigation.compose.rememberNavController
import com.subgenius.app.engine.SpeechToText
import com.subgenius.app.ui.AppViewModel
import com.subgenius.app.ui.components.CrashDialog
import com.subgenius.app.ui.components.DisclaimerDialog
import com.subgenius.app.ui.navigation.NavGraph
import com.subgenius.app.ui.theme.BgDark
import com.subgenius.app.ui.theme.SubGeniusTheme

class MainActivity : ComponentActivity() {
    private val appViewModel: AppViewModel by viewModels()

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        // عند الذهاب للخلفية نحرّر نموذج Vosk المخزّن (إن لم تكن هناك معالجة جارية)
        if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN) { SpeechToText.releaseModel(); com.subgenius.app.engine.WhisperSpeech.releaseModel() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashReporter.install(this)
        val prefs = getSharedPreferences("subgenius_prefs", MODE_PRIVATE)
        Thread {
            val prefixes = listOf("input_", "compressed_", "burned_", "audio_", "subs_", "vosk_", "chunk_", "dub_", "dubbed_", "tts_")
            cacheDir.listFiles()?.forEach { f ->
                if (f.isFile && prefixes.any { f.name.startsWith(it) }) runCatching { f.delete() }
            }
        }.start()
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )
        setContent {
            SubGeniusTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    var accepted by remember { mutableStateOf(prefs.getBoolean("disclaimer_accepted", false)) }
                    var crash by remember { mutableStateOf(CrashReporter.read(this@MainActivity)) }
                    Surface(Modifier.fillMaxSize(), color = BgDark) {
                        Scaffold(containerColor = BgDark) { padding ->
                            NavGraph(
                                navController = rememberNavController(),
                                appViewModel = appViewModel,
                                modifier = Modifier.padding(padding)
                            )
                        }
                    }
                    if (!accepted) {
                        DisclaimerDialog(onAccept = {
                            prefs.edit().putBoolean("disclaimer_accepted", true).apply()
                            accepted = true
                        })
                    } else {
                        crash?.let { report ->
                            CrashDialog(report, onClose = { CrashReporter.clear(this@MainActivity); crash = null })
                        }
                    }
                }
            }
        }
    }
}
