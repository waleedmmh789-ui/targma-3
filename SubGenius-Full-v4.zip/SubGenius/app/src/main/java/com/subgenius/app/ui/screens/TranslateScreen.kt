package com.subgenius.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.subgenius.app.engine.OnlineTranslator
import com.subgenius.app.engine.TranslatorHelper
import com.subgenius.app.ui.AppViewModel
import com.subgenius.app.ui.components.TopBar
import com.subgenius.app.ui.theme.BgDark
import com.subgenius.app.ui.theme.ErrRed
import com.subgenius.app.ui.theme.Secondary
import com.subgenius.app.ui.theme.SurfaceDark
import com.subgenius.app.ui.theme.TextGray
import com.subgenius.app.ui.theme.TextWhite
import com.subgenius.app.ui.theme.WarnYellow
import kotlinx.coroutines.launch

private val langs = listOf(
    "ar" to "العربية", "en" to "English", "fr" to "Français", "es" to "Español", "de" to "Deutsch",
    "tr" to "Türkçe", "ru" to "Русский", "zh" to "中文", "ja" to "日本語", "el" to "Ελληνικά"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TranslateScreen(appViewModel: AppViewModel, onBack: () -> Unit, onDone: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val state by appViewModel.state.collectAsState()
    var source by remember { mutableStateOf(state.sourceLang) }
    var target by remember {
        mutableStateOf(if (state.targetLang == state.sourceLang) (if (state.sourceLang == "ar") "en" else "ar") else state.targetLang)
    }
    var online by remember { mutableStateOf(true) }
    var lingvaUrl by remember { mutableStateOf(OnlineTranslator.getCustomLingva(context)) }
    var working by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var error by remember { mutableStateOf<String?>(null) }
    var notice by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().background(BgDark).padding(horizontal = 20.dp).verticalScroll(rememberScrollState())) {
        TopBar("ترجمة النص", onBack)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            LangDropdown("من", source, Modifier.weight(1f)) { source = it }
            LangDropdown("إلى", target, Modifier.weight(1f)) { target = it }
        }
        Spacer(Modifier.height(12.dp))
        Text("محرك الترجمة:", color = TextGray, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = online, onClick = { online = true }, label = { Text("أونلاين مجاني (أدق)") }, enabled = !working)
            FilterChip(selected = !online, onClick = { online = false }, label = { Text("بدون إنترنت (ML Kit)") }, enabled = !working)
        }
        if (online) {
            Text(
                "يُرسل النص إلى خوادم Lingva ثم MyMemory المجانية. قد تتوقف أو تُحدّ، وعندها تُستخدم الترجمة دون إنترنت تلقائياً.",
                color = TextGray, fontSize = 11.sp
            )
            OutlinedTextField(
                value = lingvaUrl,
                onValueChange = { lingvaUrl = it; OnlineTranslator.setCustomLingva(context, it) },
                label = { Text("خادم Lingva خاص (اختياري، https://...)") },
                singleLine = true, modifier = Modifier.fillMaxWidth(), enabled = !working
            )
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                scope.launch {
                    error = null; notice = null
                    if (source == target) { error = "اختر لغتين مختلفتين"; return@launch }
                    working = true; progress = 0
                    val segs = state.originalSegments
                    val r = if (online) {
                        val o = OnlineTranslator.translateSegments(context, source, target, segs) { progress = it }
                        if (o.isSuccess) o else {
                            notice = "تعذّرت الترجمة أونلاين (${o.exceptionOrNull()?.message}). استُخدمت الترجمة دون إنترنت."
                            progress = 0
                            TranslatorHelper.translateSegments(source, target, segs) { progress = it }
                        }
                    } else TranslatorHelper.translateSegments(source, target, segs) { progress = it }
                    working = false
                    r.onSuccess { appViewModel.setTranslatedSegments(it, source, target) }
                        .onFailure { error = it.message }
                }
            },
            enabled = !working && state.originalSegments.isNotEmpty(),
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        ) {
            if (working) {
                CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(8.dp)); Text("$progress%")
            } else Text("ترجمة")
        }
        if (state.originalSegments.isEmpty()) {
            Text("لم يتم استخراج النص بعد. ارجع إلى شاشة الاستخراج.", color = WarnYellow, fontSize = 12.sp)
        }
        Text("ترجمة ML Kit تنزّل نموذج كل لغة عند أول استخدام (تحتاج إنترنت).", color = TextGray, fontSize = 11.sp)
        notice?.let { Text(it, color = WarnYellow, fontSize = 12.sp) }
        error?.let { Text(it, color = ErrRed, fontSize = 14.sp) }
        if (state.translatedSegments.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            state.translatedSegments.forEach {
                Card(Modifier.fillMaxWidth().padding(vertical = 2.dp), colors = CardDefaults.cardColors(containerColor = SurfaceDark)) {
                    Text(it.text, Modifier.padding(8.dp), color = TextWhite)
                }
            }
            Spacer(Modifier.height(16.dp))
            Button(onClick = onDone, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Secondary)) {
                Text("تخصيص الترجمة")
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun LangDropdown(label: String, selected: String, modifier: Modifier, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text("$label: ${langs.firstOrNull { it.first == selected }?.second ?: selected}", color = TextWhite)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            langs.forEach { (c, n) -> DropdownMenuItem(text = { Text(n) }, onClick = { onSelect(c); expanded = false }) }
        }
    }
}
