package com.subgenius.app.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties

private const val SHORT_DISCLAIMER = "هذا التطبيق أداة مساعدة للترجمة والدبلجة تعمل على جهازك. أنت وحدك المسؤول عن الفيديوهات التي تعالجها وعن طريقة استعمال النتائج، ويشمل ذلك حقوق النشر وموافقة أصحاب الأصوات وعدم استعمال الدبلجة في الانتحال أو الخداع أو الإساءة. المطوّر غير مسؤول عن أي سوء استخدام ولا عن أي ضرر ينتج عنه. التفاصيل الكاملة في شاشة «حول التطبيق»."

/** يظهر مرة واحدة عند أول تشغيل ولا يُغلق إلا بالموافقة */
@Composable
fun DisclaimerDialog(onAccept: () -> Unit) {
    AlertDialog(
        onDismissRequest = {},
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false),
        title = { Text("إخلاء مسؤولية") },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) { Text(SHORT_DISCLAIMER, fontSize = 14.sp) } },
        confirmButton = { TextButton(onClick = onAccept) { Text("أوافق وأتابع") } }
    )
}

/** يعرض نص آخر انهيار حدث للتطبيق لتصويره أو نسخه وإرساله للمطوّر */
@Composable
fun CrashDialog(report: String, onClose: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("حدث خطأ في التشغيل السابق") },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) { Text(report, fontSize = 11.sp) } },
        confirmButton = { TextButton(onClick = { clipboard.setText(AnnotatedString(report)) }) { Text("نسخ النص") } },
        dismissButton = { TextButton(onClick = onClose) { Text("إغلاق") } }
    )
}
