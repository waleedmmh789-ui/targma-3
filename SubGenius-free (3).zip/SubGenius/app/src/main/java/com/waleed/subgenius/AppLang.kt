package com.waleed.subgenius

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale

/** لغة الواجهة (ar / en). حالة Compose، فيتغير النص فوراً عند التبديل. */
object AppLang {
    private const val PREFS = "settings"
    private const val KEY = "ui_lang"

    var lang by mutableStateOf("ar")
        private set

    val isArabic: Boolean get() = lang == "ar"

    fun init(context: Context) {
        val saved = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
        lang = saved ?: if (Locale.getDefault().language == "ar") "ar" else "en"
    }

    fun set(context: Context, value: String) {
        lang = value
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, value).apply()
    }
}

/** يختار النص حسب لغة الواجهة الحالية (يعمل داخل Compose وخارجه) */
fun tr(ar: String, en: String): String = if (AppLang.lang == "ar") ar else en
