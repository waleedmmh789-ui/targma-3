package com.waleed.subgenius.engine

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.waleed.subgenius.tr
import kotlinx.coroutines.CancellableContinuation
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.io.RandomAccessFile
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.coroutineContext
import kotlin.coroutines.resume

data class VoiceOption(val name: String, val label: String, val needsNetwork: Boolean)

/** دبلجة صوتية بمحرك TTS الموجود على الهاتف (أصوات الهاتف المثبّتة فقط) */
object DubbingHelper {
    private const val BYTES_PER_MS = 32            // PCM 16kHz mono 16-bit
    private const val MAX_SPEEDUP = 1.8            // أقصى تسريع لجعل الجملة تتسع في مكانها

    /** ينشئ TextToSpeech وينتظر جاهزيته (null إن لم يتوفر محرك) */
    suspend fun initTts(context: Context): TextToSpeech? = withContext(Dispatchers.Main) {
        suspendCancellableCoroutine { cont ->
            var tts: TextToSpeech? = null
            tts = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) cont.resume(tts)
                else { tts?.shutdown(); cont.resume(null) }
            }
            cont.invokeOnCancellation { tts?.shutdown() }
        }
    }

    /** الأصوات المثبّتة للغة المطلوبة (المحلية أولاً ثم الأعلى جودة) */
    fun voicesFor(tts: TextToSpeech, lang: String): List<VoiceOption> {
        val all = try { tts.voices ?: emptySet() } catch (e: Exception) { emptySet() }
        val list = all.filter { it.locale.language == lang && it.features?.contains("notInstalled") != true }
            .sortedWith(compareBy({ it.isNetworkConnectionRequired }, { -it.quality }, { it.name }))
            .mapIndexed { i, v ->
                val net = if (v.isNetworkConnectionRequired) tr(" (يحتاج إنترنت)", " (needs internet)") else ""
                VoiceOption(v.name, "${tr("صوت", "Voice")} ${i + 1} • ${v.locale.toLanguageTag()}$net", v.isNetworkConnectionRequired)
            }
        return list.ifEmpty { listOf(VoiceOption("", tr("الصوت الافتراضي", "Default voice"), false)) }
    }

    /** يطبّق الصوت والسرعة والنبرة. يرجع false إن كانت اللغة غير مدعومة */
    fun applyVoice(tts: TextToSpeech, lang: String, voiceName: String?, rate: Float, pitch: Float): Boolean {
        var ok = true
        val voice = if (!voiceName.isNullOrEmpty()) tts.voices?.firstOrNull { it.name == voiceName } else null
        if (voice != null) {
            tts.setVoice(voice)
        } else {
            val r = tts.setLanguage(Locale.forLanguageTag(lang))
            ok = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
        }
        tts.setSpeechRate(rate)
        tts.setPitch(pitch)
        return ok
    }

    private class SynthWaiter : UtteranceProgressListener() {
        val pending = ConcurrentHashMap<String, CancellableContinuation<Boolean>>()
        override fun onStart(utteranceId: String?) {}
        override fun onDone(utteranceId: String?) {
            pending.remove(utteranceId)?.let { if (it.isActive) it.resume(true) }
        }
        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) {
            pending.remove(utteranceId)?.let { if (it.isActive) it.resume(false) }
        }
        override fun onError(utteranceId: String?, errorCode: Int) { onError(utteranceId) }
    }

    private suspend fun synth(tts: TextToSpeech, waiter: SynthWaiter, text: String, out: File, id: String): Boolean =
        suspendCancellableCoroutine { cont ->
            waiter.pending[id] = cont
            val r = tts.synthesizeToFile(text, Bundle(), out, id)
            if (r != TextToSpeech.SUCCESS) {
                waiter.pending.remove(id)
                if (cont.isActive) cont.resume(false)
            }
            cont.invokeOnCancellation { waiter.pending.remove(id); tts.stop() }
        }

    /** يضيف عينات PCM إلى مكانها في ملف المزج (جمع مع تقييد) */
    private fun mixInto(raf: RandomAccessFile, pcm: File, offsetBytes: Long) {
        val data = pcm.readBytes()
        val off = offsetBytes / 2 * 2
        val existing = ByteArray(data.size)
        raf.seek(off)
        val n = raf.read(existing).coerceAtLeast(0)
        var i = 0
        while (i + 1 < data.size) {
            val a = (data[i].toInt() and 0xFF) or (data[i + 1].toInt() shl 8)
            val b = if (i + 1 < n) (existing[i].toInt() and 0xFF) or (existing[i + 1].toInt() shl 8) else 0
            val s = (a + b).coerceIn(-32768, 32767)
            data[i] = (s and 0xFF).toByte()
            data[i + 1] = ((s shr 8) and 0xFF).toByte()
            i += 2
        }
        raf.seek(off)
        raf.write(data)
    }

    /** يدبلج الفيديو: ينطق كل مقطع في مكانه الزمني ويدمجه مع الفيديو */
    suspend fun dub(
        context: Context, tts: TextToSpeech, videoFile: File, segments: List<SpeechSegment>, lang: String,
        voiceName: String?, rate: Float, pitch: Float, bgVolume: Float, onProgress: (Int) -> Unit
    ): Result<File> = withContext(Dispatchers.IO) {
        val temps = mutableListOf<File>()
        try {
            val durationMs = FFmpegHelper.probeDurationMs(videoFile)
            if (durationMs <= 0) return@withContext Result.failure(Exception(tr("تعذّر قراءة مدة الفيديو", "Could not read the video duration")))
            if (!applyVoice(tts, lang, voiceName, rate, pitch))
                return@withContext Result.failure(Exception(tr("لغة الدبلجة غير مدعومة في محرك الصوت بهاتفك", "The dubbing language is not supported by your phone's voice engine")))
            val waiter = SynthWaiter()
            tts.setOnUtteranceProgressListener(waiter)

            val stamp = System.currentTimeMillis()
            val mix = File(context.cacheDir, "dub_mix_$stamp.pcm").also { temps += it }
            val sorted = segments.filter { it.text.isNotBlank() }.sortedBy { it.startMs }
            if (sorted.isEmpty()) return@withContext Result.failure(Exception(tr("لا يوجد نص للدبلجة", "No text to dub")))
            var spoken = 0

            RandomAccessFile(mix, "rw").use { raf ->
                raf.setLength(durationMs * BYTES_PER_MS + 64000)
                sorted.forEachIndexed { i, seg ->
                    coroutineContext.ensureActive()
                    val wav = File(context.cacheDir, "dub_${stamp}_$i.wav").also { temps += it }
                    val ok = withTimeoutOrNull(30_000) { synth(tts, waiter, seg.text, wav, "dub$i") } ?: false
                    if (ok && wav.length() > 100) {
                        val nextStart = sorted.getOrNull(i + 1)?.startMs ?: durationMs
                        val avail = (nextStart - seg.startMs).coerceAtLeast(500)
                        val dur = FFmpegHelper.probeDurationMs(wav)
                        val tempo = if (dur > avail) (dur.toDouble() / avail).coerceIn(1.0, MAX_SPEEDUP) else 1.0
                        val pcm = File(context.cacheDir, "dub_${stamp}_$i.pcm").also { temps += it }
                        if (FFmpegHelper.toPcm16k(wav, pcm, tempo)) {
                            mixInto(raf, pcm, seg.startMs * BYTES_PER_MS)
                            spoken++
                        }
                    }
                    runCatching { wav.delete() }
                    onProgress(((i + 1) * 85) / sorted.size)
                }
            }
            if (spoken == 0)
                return@withContext Result.failure(Exception(tr("لم ينتج محرك الصوت أي كلام. تحقق من بيانات الصوت في إعدادات تحويل النص إلى كلام.", "The voice engine produced no speech. Check the voice data in your Text-to-speech settings.")))

            val out = File(context.cacheDir, "dubbed_$stamp.mp4")
            val ok = FFmpegHelper.muxDub(videoFile, mix, out, bgVolume, durationMs) { onProgress(85 + it * 14 / 100) }
            if (!ok) return@withContext Result.failure(Exception(tr("فشل دمج الصوت مع الفيديو", "Failed to mix the audio into the video")))
            onProgress(100)
            Result.success(out)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            Result.failure(e)
        } finally {
            temps.forEach { runCatching { it.delete() } }
        }
    }
}
