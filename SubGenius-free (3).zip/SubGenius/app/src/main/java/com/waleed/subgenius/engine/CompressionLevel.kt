package com.waleed.subgenius.engine

import com.waleed.subgenius.tr

/**
 * q: جودة mpeg4 البرمجي (الأقل = أفضل). maxWidth: أقصى عرض (0 = بدون تصغير).
 * hwBitrate: معدل البت للترميز العتادي h264_mediacodec.
 */
enum class CompressionLevel(
    val q: Int, val maxWidth: Int, val hwBitrate: Int,
    private val labelAr: String, private val labelEn: String
) {
    LIGHT(3, 0, 6_000_000, "خفيف - جودة عالية", "Light - high quality"),
    MEDIUM(5, 1280, 3_000_000, "متوسط - جودة جيدة", "Medium - good quality"),
    STRONG(8, 854, 1_500_000, "قوي - جودة مقبولة", "Strong - acceptable quality"),
    NONE(0, 0, 0, "بدون ضغط", "No compression");

    val label: String get() = tr(labelAr, labelEn)
}
