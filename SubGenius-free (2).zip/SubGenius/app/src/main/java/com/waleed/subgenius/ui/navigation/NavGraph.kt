package com.waleed.subgenius.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.waleed.subgenius.ui.AppViewModel
import com.waleed.subgenius.ui.screens.AboutScreen
import com.waleed.subgenius.ui.screens.CustomizeScreen
import com.waleed.subgenius.ui.screens.DownloadScreen
import com.waleed.subgenius.ui.screens.EditTextScreen
import com.waleed.subgenius.ui.screens.ExtractScreen
import com.waleed.subgenius.ui.screens.HomeScreen
import com.waleed.subgenius.ui.screens.ProjectsScreen
import com.waleed.subgenius.ui.screens.TranslateScreen
import com.waleed.subgenius.ui.screens.VideoScreen

object Routes {
    const val HOME = "home"
    const val VIDEO = "video"
    const val EXTRACT = "extract"
    const val TRANSLATE = "translate"
    const val CUSTOMIZE = "customize"
    const val EDIT_ORIGINAL = "edit_original"
    const val EDIT_TRANSLATED = "edit_translated"
    const val PROJECTS = "projects"
    const val DOWNLOAD = "download"
    const val ABOUT = "about"
}

@Composable
fun NavGraph(navController: NavHostController, appViewModel: AppViewModel, modifier: Modifier = Modifier) {
    NavHost(navController, startDestination = Routes.HOME, modifier = modifier) {
        composable(Routes.HOME) {
            HomeScreen(
                onPickVideo = { uri -> appViewModel.setVideo(uri); navController.navigate(Routes.VIDEO) },
                onOpenProjects = { navController.navigate(Routes.PROJECTS) },
                onOpenDownload = { navController.navigate(Routes.DOWNLOAD) },
                onOpenAbout = { navController.navigate(Routes.ABOUT) }
            )
        }
        composable(Routes.VIDEO) {
            VideoScreen(
                appViewModel = appViewModel,
                onBack = { navController.popBackStack() },
                onExtract = { navController.navigate(Routes.EXTRACT) },
                onTranslate = { navController.navigate(Routes.TRANSLATE) },
                onCustomize = { navController.navigate(Routes.CUSTOMIZE) }
            )
        }
        composable(Routes.EXTRACT) {
            ExtractScreen(
                appViewModel = appViewModel,
                onBack = { navController.popBackStack() },
                onDone = { navController.navigate(Routes.TRANSLATE) },
                onEdit = { navController.navigate(Routes.EDIT_ORIGINAL) }
            )
        }
        composable(Routes.TRANSLATE) {
            TranslateScreen(
                appViewModel = appViewModel,
                onBack = { navController.popBackStack() },
                onDone = { navController.navigate(Routes.CUSTOMIZE) },
                onEdit = { navController.navigate(Routes.EDIT_TRANSLATED) }
            )
        }
        composable(Routes.CUSTOMIZE) {
            CustomizeScreen(appViewModel = appViewModel, onBack = { navController.popBackStack() })
        }
        composable(Routes.EDIT_ORIGINAL) {
            EditTextScreen(appViewModel = appViewModel, translated = false, onBack = { navController.popBackStack() })
        }
        composable(Routes.EDIT_TRANSLATED) {
            EditTextScreen(appViewModel = appViewModel, translated = true, onBack = { navController.popBackStack() })
        }
        composable(Routes.PROJECTS) { ProjectsScreen(onBack = { navController.popBackStack() }) }
        composable(Routes.ABOUT) { AboutScreen(onBack = { navController.popBackStack() }) }
        composable(Routes.DOWNLOAD) { DownloadScreen(onBack = { navController.popBackStack() }) }
    }
}
