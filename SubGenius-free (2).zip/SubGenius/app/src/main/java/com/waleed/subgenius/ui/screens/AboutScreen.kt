package com.waleed.subgenius.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.waleed.subgenius.tr
import com.waleed.subgenius.ui.components.TopBar
import com.waleed.subgenius.ui.theme.BgDark
import com.waleed.subgenius.ui.theme.Primary
import com.waleed.subgenius.ui.theme.Secondary
import com.waleed.subgenius.ui.theme.SurfaceDark
import com.waleed.subgenius.ui.theme.TextGray
import com.waleed.subgenius.ui.theme.TextWhite

private const val SUPPORT_EMAIL = "waleedmmh789@gmail.com"
private const val PRIVACY_URL = "https://sites.google.com/view/subgenius-app/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9-%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D8%A9"

@Composable
fun AboutScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val version = remember {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "1.0.0"
    }

    Column(Modifier.fillMaxSize().background(BgDark).padding(horizontal = 20.dp).verticalScroll(rememberScrollState())) {
        TopBar(tr("حول التطبيق والدعم", "About & support"), onBack)

        Block {
            Text(tr("عبقري الترجمة (SubGenius)", "SubGenius (Translation Genius)"), color = TextWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Line(tr("المطور", "Developer"), "Waleed")
            Line(tr("الإصدار", "Version"), version)
            Line(tr("الدعم والتواصل", "Support & contact"), SUPPORT_EMAIL)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { sendSupportEmail(context, version) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Primary)
                ) { Text(tr("مراسلة الدعم", "Email support")) }
                OutlinedButton(onClick = { copyEmail(context) }, modifier = Modifier.weight(1f)) {
                    Text(tr("نسخ البريد", "Copy email"), color = TextWhite)
                }
            }
            OutlinedButton(onClick = { openPrivacy(context) }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                Text(tr("سياسة الخصوصية", "Privacy policy"), color = TextWhite)
            }
        }

        Block(tr("1. إمكانيات التطبيق", "1. App capabilities")) {
            Item(
                tr("استخراج النص من الفيديو", "Video speech-to-text"),
                tr("تحويل الكلام المسموع في الفيديو إلى نص مقسم إلى مقاطع باستخدام محركي Vosk و Whisper (مع إمكانية تنزيل وإدارة النماذج وحزم اللغات).",
                   "Transcribes spoken audio in videos into segmented text using the Vosk and Whisper engines (with model and language pack management).")
            )
            Item(
                tr("الترجمة", "Translation"),
                tr("ترجمة المقاطع النصية عبر Google ML Kit (بدون إنترنت بعد تنزيل نموذج اللغة) أو عبر خدمات الترجمة الأونلاين المجانية المتاحة للنص فقط (مثل Lingva و MyMemory).",
                   "Translates text segments via Google ML Kit (offline after downloading the language model) or free online text-only translation services (such as Lingva and MyMemory).")
            )
            Item(
                tr("التعديل والنسخ للتصحيح", "Edit & copy-paste correction"),
                tr("مراجعة النص المستخرج وتعديله داخل التطبيق، أو نسخ النص ولصقه لتصحيحه في أداة أو محرر خارجي ثم إعادته قبل الترجمة أو الحرق النهائي.",
                   "Review and edit extracted text inside the app, or copy and paste it into an external editor/tool for correction before translating or burning subtitles.")
            )
            Item(
                tr("تخصيص وحرق الترجمة", "Subtitle customization & burn-in"),
                tr("مراجعة وتخصيص النصوص وضبط حجم الخط وحرق الترجمة على الفيديو وحفظ النتيجة في المعرض داخل مجلد Movies/SubGenius.",
                   "Customize text, adjust font size, hard-burn subtitles onto the video and save the result to the gallery under Movies/SubGenius.")
            )
            Item(
                tr("إدارة المشاريع والخصوصية", "Projects & privacy"),
                tr("حفظ قائمة «مشاريعي» محلياً على الهاتف (اسم المشروع، اللغتان، الحالة، ومسار الفيديو الناتج)، وحذف الملفات المؤقتة تلقائياً، مع بقاء معالجة الفيديو والصوت محلية على الهاتف (ويُرسل نص الترجمة فقط عند اختيار الترجمة الأونلاين) وعدم وجود حسابات أو تتبع.",
                   "Stores your \"My projects\" list locally on the device (project name, languages, status, and output video path), automatically cleans up temporary files, and keeps video and audio processing local (only the subtitle text is sent if you choose online translation). No accounts or tracking.")
            )
        }

        Block(tr("2. السرعة مقابل البطء (Vosk أم Whisper؟)", "2. Speed vs. slowness (Vosk or Whisper?)")) {
            Item(
                tr("Vosk (الأسرع)", "Vosk (faster)"),
                tr("أسرع بكثير في تفريغ الكلام—خاصة للفصحى والمقاطع الواضحة—ويُعد خياراً عملياً للسرعة وتجربة الاستخدام اليومية.",
                   "Significantly faster at transcribing speech—especially clear speech and Standard Arabic—making it a practical choice for speed and everyday use.")
            )
            Item(
                tr("Whisper (أبطأ، خصوصاً مع العربية)", "Whisper (slower, especially for Arabic)"),
                tr("قد يستغرق وقتاً أطول بكثير (عدة دقائق حتى للمقاطع القصيرة) لأنه يعمل محلياً على معالج الهاتف بنماذج أثقل، وتتأثر سرعته بحجم النموذج المختار وطول الفيديو وحالة الجهاز.",
                   "May take considerably longer (even several minutes for short clips) because it runs locally on the device processor using heavier models, with speed varying by selected model size, video length, and device state.")
            )
        }

        Block(tr("3. تنويه حول أخطاء التفريغ والترجمة وسببها", "3. Notice on transcription & translation errors")) {
            Para(
                tr("قد تظهر بعض الأخطاء الإملائية أو الكلمات غير الدقيقة في النص المستخرج أو الترجمة؛ ويرجع ذلك إلى طبيعة التعرف الآلي على الكلام (مثل تشابه الأصوات، اختلاف اللهجات، الضوضاء الخلفية، أو سرعة الإلقاء)، كما أن أي خطأ في النص الأصلي قد ينتقل إلى الترجمة الناتجة عنه.",
                   "Spelling mistakes or inaccurate words may appear in the extracted text or translation due to the nature of automatic speech recognition (such as similar-sounding words, dialects, background noise, or speaking speed), and any error in the source text may carry over into the resulting translation.")
            )
            Para(
                tr("يُنصح بمراجعة النص المستخرج وتصحيحه يدوياً أو نسخه ولصقه لتصحيحه خارج التطبيق قبل الاعتماد عليه في الترجمة أو الحرق النهائي.",
                   "You are advised to review and correct the extracted text manually, or copy and paste it to fix it outside the app before translating or burning subtitles.")
            )
        }

        Block(tr("4. الدعم الفني والتواصل", "4. Support & contact")) {
            Item(tr("البريد الإلكتروني للدعم", "Support email"), SUPPORT_EMAIL)
            Item(
                tr("متى تتواصل مع الدعم؟", "When to reach out"),
                tr("للاستفسارات، والإبلاغ عن الأعطال أو مشاكل التشغيل، أو إرسال الاقتراحات والملاحظات المتعلقة بالتطبيق.",
                   "For inquiries, reporting bugs or playback issues, or sharing feedback and feature suggestions.")
            )
            Item(
                tr("ما يُنصح بإرفاقه عند التواصل", "Helpful details to include"),
                tr("اسم أو إصدار التطبيق، نوع الجهاز وإصدار أندرويد، المحرك المستخدم (Vosk أو Whisper)، ووصف مختصر للخطوات التي سبقت المشكلة ليسهل فهمها ومعالجتها. (زر «مراسلة الدعم» يضيف بيانات الجهاز والإصدار تلقائياً.)",
                   "App name/version, device model and Android version, engine used (Vosk or Whisper), and a brief description of the steps leading to the issue. (The \"Email support\" button adds your device and version details automatically.)")
            )
        }

        Block(tr("5. إخلاء المسؤولية القانونية والأدبية", "5. Legal & moral disclaimer")) {
            Item(
                tr("المسؤولية الكاملة على المستخدم", "Full user responsibility"),
                tr("يقر المستخدم ويتحمل المسؤولية القانونية والأدبية والأخلاقية الكاملة وحده عن أي محتوى يقوم باستخراج نصه أو ترجمته أو حرق ترجمة عليه أو نشره أو مشاركته باستخدام التطبيق.",
                   "The user acknowledges and assumes full legal, moral, and ethical responsibility alone for any content transcribed, translated, hard-subtitled, published, or shared using the app.")
            )
            Item(
                tr("حقوق الملكية والفكرية", "Copyright & intellectual property"),
                tr("المستخدم مسؤول بالكامل عن امتلاك الحقوق أو التراخيص اللازمة لترجمة أو إعادة استخدام فيديوهات أو مواد الغير، وعن الالتزام بقوانين حقوق النشر والملكية الفكرية والأنظمة المعمول بها في بلده والمنصات التي ينشر عليها.",
                   "The user is solely responsible for holding the necessary rights or licenses to translate or reuse third-party videos or materials, and for complying with applicable copyright, intellectual property, and platform laws.")
            )
            Item(
                tr("التعديل على النصوص والمحتوى", "Editing texts & content"),
                tr("يتحمل المستخدم وحده تبعات أي تعديل أو تحريف أو تصرف يجرى على النص المستخرج أو المترجم سواء داخل التطبيق أو بعد نسخه ولصقه وتعديله خارجه، وما يترتب على ذلك من أثر قانوني أو أدبي أو اجتماعي تجاه أصحاب المحتوى أو أي طرف ثالث.",
                   "The user bears sole responsibility for any edits, alterations, or actions performed on extracted or translated text—whether inside the app or after copying and editing it externally—and for any legal, moral, or social consequences toward content owners or third parties.")
            )
            Item(
                tr("عدم مسؤولية المطور", "No developer liability"),
                tr("يُقدَّم التطبيق «كما هو» (As-Is) دون أي تعهدات أو ضمانات صريحة أو ضمنية بشأن دقة التفريغ الآلي أو الترجمة أو ملاءمة النتيجة لغرض محدد، ولا تقع أدنى مسؤولية قانونية أو أدبية أو مادية على مطور التطبيق تجاه المستخدم أو أي طرف ثالث عن أي أضرار مباشرة أو غير مباشرة أو نزاعات تنشأ عن استخدام التطبيق أو إساءة استخدامه أو عن نصوص أو فيديوهات يختارها أو يعدّلها المستخدم بنفسه.",
                   "The app is provided \"As-Is\" without any express or implied warranties regarding transcription accuracy, translation quality, or fitness for a particular purpose, and the app developer bears no legal, moral, or material liability toward the user or any third party for any direct or indirect damages or disputes arising from use or misuse of the app or from content chosen or modified by the user.")
            )
        }
        Spacer(Modifier.height(32.dp))
    }
}

@Composable
private fun Block(title: String? = null, content: @Composable () -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(vertical = 6.dp), shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Column(Modifier.padding(16.dp)) {
            title?.let {
                Text(it, color = Secondary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
            }
            content()
        }
    }
}

@Composable
private fun Item(title: String, body: String) {
    Column(Modifier.padding(bottom = 10.dp)) {
        Text(title, color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        Text(body, color = TextGray, fontSize = 13.sp)
    }
}

@Composable
private fun Para(text: String) {
    Text(text, color = TextGray, fontSize = 13.sp, modifier = Modifier.padding(bottom = 10.dp))
}

@Composable
private fun Line(label: String, value: String) {
    Row { Text("$label: ", color = TextGray, fontSize = 13.sp); Text(value, color = TextWhite, fontSize = 13.sp) }
}

private fun sendSupportEmail(context: Context, version: String) {
    val body = "\n\n---\nApp: SubGenius $version\nDevice: ${Build.MANUFACTURER} ${Build.MODEL}\n" +
        "Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\nEngine (Vosk/Whisper): \nSteps: \n"
    val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:")).apply {
        putExtra(Intent.EXTRA_EMAIL, arrayOf(SUPPORT_EMAIL))
        putExtra(Intent.EXTRA_SUBJECT, "SubGenius support")
        putExtra(Intent.EXTRA_TEXT, body)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    try { context.startActivity(intent) } catch (e: Exception) {
        Toast.makeText(context, tr("لا يوجد تطبيق بريد. البريد: $SUPPORT_EMAIL", "No email app found. Email: $SUPPORT_EMAIL"), Toast.LENGTH_LONG).show()
    }
}

private fun copyEmail(context: Context) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("email", SUPPORT_EMAIL))
    Toast.makeText(context, tr("تم نسخ البريد", "Email copied"), Toast.LENGTH_SHORT).show()
}

private fun openPrivacy(context: Context) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(PRIVACY_URL)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        Toast.makeText(context, tr("تعذّر فتح الرابط", "Could not open the link"), Toast.LENGTH_SHORT).show()
    }
}
